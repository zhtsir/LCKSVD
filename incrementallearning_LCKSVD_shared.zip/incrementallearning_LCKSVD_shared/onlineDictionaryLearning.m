function [model,stat] = onlineDictionaryLearning(pars, trainingdata, HMat, QMat)
% online dictionary learning using stochastic gradient descent algorithm
% Inputs:
%    -para: learning paramters
%       .D: initial dictionary
%       .A: initial transform matrix
%       .W: initial classifier
%       .mu: reguliarization parameter
%       .nu1: reguliarization parameter
%       .nu2: reguliarization parameter
%       .maxIters: iteration number
%       .rho: learning rate parameter
%    -trainingdata: input training des. with size of n X N
%    -HMat: label matrix of training des. with size of m X N
%    -QMat: optimal code matrix of training des. with size of K X N
%
% Outputs:
%    -model: learned paramters
%       .D: learned dictionary
%       .A: learned transform matrix
%       .W: learned classifier
%    -stat:
%       .fobj_avg: average objective function value
%
%  Author: Zhuolin Jiang (zhuolin@umiacs.umd.edu)
%


num_images = size(trainingdata,2);
num_bases = pars.numBases;
num_iters = pars.maxIters;
gamma = pars.gamma; % sparse coding parameters
lambda = pars.lambda;
nu1 = pars.nu1;
nu2 = pars.nu2;
mu = pars.mu;
rho = pars.rho;
%n0 = num_images/10
n0 = num_images/(pars.batchSize*10);
model.D = pars.D; % dictionary
model.W = pars.W; % classifier
model.A = pars.A; % transform matrix


param.lambda = pars.lambda;
param.lambda2 = 0;
param.mode = 2;

% crf iterations
for iter = 1 : num_iters
    tic;
    stat.fobj_total = 0;
    % Take a random permutation of the samples
    try
        load(fullfile('tmp',sprintf('permute_%d_%d_%s.mat',iter,num_bases,pars.dataset)),'ind_rnd');
    catch
        ind_rnd = randperm(num_images);
        save(fullfile('tmp',sprintf('permute_%d_%d_%s.mat',iter,num_bases,pars.dataset)),'ind_rnd');
    end
    
    for batch = 1:(num_images/pars.batchSize)
        % load the dataset
        % we only loads one sample or a small batch at each iteration
        batch_idx = ind_rnd((1:pars.batchSize)+pars.batchSize*(batch-1));
        yt = trainingdata(:,batch_idx);
        ht = HMat(:,batch_idx);
        qt = QMat(:,batch_idx);
        
        D = model.D;
        W = model.W;
        A = model.A;
        
        % sparse coding
        %S = L1QP_FeatureSign_Set(yt, D, gamma, lambda);
        S = mexLasso(yt,D,param);
       
        % compute the gradient of crf parameters       
        grad_W = (1-mu)*(W*S - ht)*S' + nu2*W; %
        grad_A = mu*(A*S - qt)*S' + nu1*A;
        grad_S1 = W'*(W*S - ht); % gradient w.r.t S for 0.5*||H-WS||_2^2
        grad_S2 = A'*(A*S - qt); % gradient w.r.t S for 0.5*||Q-AS||_2^2
        
        % compute the gradient of dictionary
        % find the active set and compute beta
        B1 = zeros(num_bases, pars.batchSize);
        B2 = zeros(num_bases, pars.batchSize);
        DtD = D'*D;
        for j = 1: pars.batchSize
            active_set = find(S(:,j) ~= 0);
            %DtD = D(:,active_set)'*D(:,active_set) + gamma*eye(length(active_set));
            DtD_hat = DtD(active_set,active_set) + gamma*eye(length(active_set));
            
            %DtD_inv = DtD\eye(length(active_set));
            DtD_inv = DtD_hat\eye(length(active_set));
            
            beta1 = DtD_inv * grad_S1(active_set,j);
            B1(active_set,j) = beta1;
            
            beta2 = DtD_inv * grad_S2(active_set,j);
            B2(active_set,j) = beta2;
        end
        grad_D = (1-mu)*(-D*B1*S' + (yt - D*S)*B1') + mu*(-D*B2*S' + (yt - D*S)*B2'); % dD = -D*B*S' + (X - D*S)*B';
        
        %use yang's method
        %gfullMat = zeros([size(D),size(D,2)]);
        %[gMat, IDX] = sparseDerivative(D, full(S), yt);
        %gfullMat(:,IDX,IDX) = gMat;
        %gradSmat = repmat(reshape(grad_S1,[1 1 length(grad_S1)]),size(D));
        %grad_D = sum(gfullMat.*gradSmat,3);
        
        % update the learning rate
        rho_i = min(rho, rho*n0/batch);
        
        % update model parameters
        D = D - rho_i*grad_D;
        l2norm = (sum(D.^2)).^.5;
        D = D ./ repmat(l2norm,size(D,1),1);
        model.D = D;
        
        W = W - rho_i*grad_W;
        model.W = W;
        
        A = A - rho_i*grad_A;
        model.A = A;
        
    end
  
    % get statistics
    S = mexLasso(trainingdata,D,param);
    fobj = getObjective_lc(D, S, trainingdata, W, HMat, A, QMat, lambda, mu);
    stat.fobj_avg(iter) = fobj + 0.5*nu1*sum(sum(W.^2)) + 0.5*nu2*sum(sum(A.^2));
    save(fullfile('tmp',sprintf('model_%d_%d_%s.mat',iter,num_bases,pars.dataset)),'model');
    fprintf('Iter = %d, Elapsed Time = %f\n', iter, toc);
end