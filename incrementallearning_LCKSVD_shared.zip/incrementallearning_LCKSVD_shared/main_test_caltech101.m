% =========================================================================
% An example code for the algorithm proposed in
%
% Zhuolin Jiang, Zhe Lin, Larry S. Davis. 
% "Label Consistent K-SVD: Learning A Discriminative Dictionary for 
% Recognition". TPAMI, 2013, 35(11): 2651-2664
%
% Author: Zhuolin Jiang (zhuolin@umiacs.umd.edu)
% Date: 12-30-2013
% =========================================================================

clear all;
close all;
%clc;
addpath(genpath('./spams-matlab/'));
addpath(genpath('./OMPbox/'));
addpath(genpath('./ksvdbox/'));
load('./trainingdata/spatialpyramidfeatures4caltech101.mat');

%% constant
personnumber = 102; % person number for evaluation
% constant for incremental dictionary learning
pars.gamma = 1e-6;
pars.lambda = 0.5;
pars.mu = 0.6; % ||Q-AX||^2
pars.nu1 = 1e-6; % regularization of A
pars.nu2 = 1e-6; % regularization of W
pars.rho = 10; % initial learning rate
pars.maxIters = 20; % iteration number for incremental learning
pars.batchSize = 60;
pars.iterationini = 5; % iteration number for initialization

pars.ntrainsamples = 30; 
pars.numBases = personnumber*pars.ntrainsamples; % dictionary size
pars.dataset = 'caltech101';

% constant for LC-KSVD2
sparsitythres = 40; % sparsity prior
sqrt_alpha = 0.0012; % weights for label constraint term
sqrt_beta = 0.0012; % weights for classification err term
iterations = 50; % iteration number
iterations4ini = 20; % iteration number for initialization
dictsize = personnumber*30; % dictionary size

%% get training and testing data
[testing_feats,H_test,training_feats,H_train] = obtaintraingtestingsamples(featureMat,labelMat,pars.ntrainsamples);

%% get the subsets of training data and testing data
% it is related to the variable 'personnumber'
[labelvector_train,~] = find(H_train);
[labelvector_test,~] = find(H_test);
trainsampleid = find(labelvector_train<=personnumber);
testsampleid = find(labelvector_test<=personnumber);
trainingsubset = training_feats(:,trainsampleid);
testingsubset = testing_feats(:,testsampleid);
H_train_subset = H_train(1:personnumber,trainsampleid);
H_test_subset = H_test(1:personnumber,testsampleid);

%% Incremental Dictionary learning
% initialization
[Dinit,Winit,Tinit,Q_train] = paramterinitialization(trainingsubset,H_train_subset, pars);

pars.D = Dinit;
pars.A = Tinit;
pars.W = Winit;

fprintf('\nIncremental dictionary learning...');
[model,stat] = onlineDictionaryLearning(pars, trainingsubset, H_train_subset, Q_train);
fprintf('done! it took %f seconds',toc);
for ii=1:pars.maxIters
    load(fullfile('tmp',sprintf('model_%d_%d_%s.mat',ii,pars.numBases,pars.dataset)),'model');
    D1 = model.D;
    W1 = model.W;
    % classification
    [~,stat.accuracy(ii)] = classification(D1, W1, testingsubset, H_test_subset, sparsitythres);
    fprintf('\nFinal recognition rate for OnlineDL is : %f , objective function value: %f', stat.accuracy(ii), stat.fobj_avg(ii));
    fprintf('%.4f ',stat.accuracy(ii));
    if ~mod(ii, 10),
        fprintf('\n');
    end
end
fprintf('Final recognition rate for OnlineDL is : %f\n', max(stat.accuracy(:)));
% plot the objective function values for all iterations
figure,
plot(stat.fobj_avg(:),'marker','o','linewidth',2,'linestyle','--','color','m');
figure,plot(stat.accuracy(:),'marker','s','linewidth',2,'linestyle','--','color','r');
